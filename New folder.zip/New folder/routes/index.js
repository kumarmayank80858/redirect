const express = require('express');
const router = express.Router();
 const { ensureAuthenticated } = require('../config/auth');
//  const isAuth = require('../config/auth');

// Welcome page
router.get('/',(req,res)=>res.render('welcome'));
//Dashboard

  router.get('/student',ensureAuthenticated,(req,res) => res.render('student'));
  // Bus 
  router.get('/bus',ensureAuthenticated,(req,res) => res.render('bus'));

  // visitor
  router.get('/visitor',ensureAuthenticated,(req,res) => res.render('visitor'));

  // RECORD-LIST
  router.get('/user/RECORD-LIST',ensureAuthenticated,(req,res) => res.render('RECORD-LIST'));
  
module.exports = router;