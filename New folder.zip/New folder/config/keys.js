module.exports =  {
    MongoURI:'mongodb://MyRoll:mayank123@mongodb01-shard-00-00-fec9f.mongodb.net:27017,mongodb01-shard-00-01-fec9f.mongodb.net:27017,mongodb01-shard-00-02-fec9f.mongodb.net:27017/test?ssl=true&replicaSet=mongodb01-shard-0&authSource=admin&retryWrites=true&w=majority'
}